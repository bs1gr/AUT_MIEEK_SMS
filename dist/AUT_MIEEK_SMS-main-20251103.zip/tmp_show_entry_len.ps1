$path = Join-Path $env:USERPROFILE ".docker\config.json"
if (Test-Path $path) {
  $c = Get-Content $path -Raw | ConvertFrom-Json
  $entry = $c.auths.'https://index.docker.io/v1/'
  if ($entry) {
    foreach ($p in $entry.PSObject.Properties) {
      if ($p.Value -ne $null) { $len = ($p.Value | Out-String).Trim().Length; Write-Output ("{0} : length={1}" -f $p.Name, $len) }
      else { Write-Output ("{0} : null" -f $p.Name) }
    }
  } else { Write-Output 'no-entry' }
} else { Write-Output 'no-config' }
