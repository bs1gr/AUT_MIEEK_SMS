$path = Join-Path $env:USERPROFILE ".docker\config.json"
if (Test-Path $path) {
  $c = Get-Content $path -Raw | ConvertFrom-Json
  $entry = $c.auths.'https://index.docker.io/v1/'
  if ($entry) {
    foreach ($p in $entry.PSObject.Properties) { Write-Output ("{0} : {1}" -f $p.Name, ($p.Value -ne $null)) }
  } else { Write-Output 'no-entry' }
} else { Write-Output 'no-config' }
