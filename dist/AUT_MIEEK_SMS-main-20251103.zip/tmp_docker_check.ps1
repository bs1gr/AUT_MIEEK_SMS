$path = Join-Path $env:USERPROFILE ".docker\config.json"
if (Test-Path $path) {
  $c = Get-Content $path -Raw | ConvertFrom-Json
  $key = $c.auths.Keys | Where-Object { $_ -like '*docker.io*' -or $_ -like '*index.docker.io*' -or $_ -eq 'https://index.docker.io/v1/' } | Select-Object -First 1
  if ($key) {
    $a = $c.auths[$key].auth
    if ($a) {
      $u = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($a)).Split(':')[0]
      Write-Output $u
    } else { Write-Output 'no-auth' }
  } else { Write-Output 'no-auth-key' }
} else { Write-Output 'no-config' }
