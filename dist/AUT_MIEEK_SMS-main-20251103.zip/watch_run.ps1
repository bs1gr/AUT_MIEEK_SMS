$owner='bs1gr'
$repo='AUT_MIEEK_SMS'
$workflow='docker-publish.yml'
$tag='v1.3.5-publish-1'
Write-Output "Watching workflow '$workflow' for tag '$tag' in $owner/$repo..."
$run=$null
for ($i=0; $i -lt 240; $i++) {
  try { $resp = Invoke-RestMethod -Uri "https://api.github.com/repos/$owner/$repo/actions/workflows/$workflow/runs" -UseBasicParsing } catch { Write-Output "Failed to query GitHub API: $_"; break }
  $run = $resp.workflow_runs | Where-Object { $_.head_branch -eq $tag } | Select-Object -First 1
  if ($null -ne $run) {
    $id=$run.id; $status=$run.status; $conclusion=$run.conclusion
    $percent = $i+1
    Write-Output "Found run id=$id status=$status conclusion=$conclusion (poll #$percent)"
    if ($status -eq 'completed') { break }
  } else {
    Write-Output "No run found yet (poll #$($i+1)). Waiting 5s..."
  }
  Start-Sleep -Seconds 5
}
if ($null -eq $run) { Write-Output 'No workflow run found for the tag after polling.'; exit 1 }
$id=$run.id
$runUrl=$run.html_url
Write-Output "Run URL: $runUrl"
Write-Output 'Waiting for run to reach completed state (final poll)...'
while ($true) {
  $r = Invoke-RestMethod -Uri "https://api.github.com/repos/$owner/$repo/actions/runs/$id" -UseBasicParsing
  Write-Output "Status: $($r.status) | Conclusion: $($r.conclusion)"
  if ($r.status -eq 'completed') { break }
  Start-Sleep -Seconds 3
}
$jobs = Invoke-RestMethod -Uri "https://api.github.com/repos/$owner/$repo/actions/runs/$id/jobs" -UseBasicParsing
Write-Output 'Jobs summary:'
foreach ($job in $jobs.jobs) {
  Write-Output "- Job: $($job.name) (id=$($job.id)) status=$($job.status) conclusion=$($job.conclusion) url=$($job.html_url)"
}
Write-Output 'Finished watching run.'
