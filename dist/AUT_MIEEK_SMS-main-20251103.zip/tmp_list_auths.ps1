$path = Join-Path $env:USERPROFILE ".docker\config.json"
if (Test-Path $path) {
  $c = Get-Content $path -Raw | ConvertFrom-Json
  $c.auths.PSObject.Properties | ForEach-Object { $_.Name }
} else { Write-Output 'no-config' }
